/* 典型用户样例，联调 / 回归时快速铺答案 */
module.exports = [
  { name:"游戏玩家 · 6~9K",
    picks:{ q2:"q2e", q3:"q3c", q4:"q4d", q5:"q5a", q6:"q6b", q7:"q7b", q8:"q8d", q9:"q9a" },
    side:{ g_work:["qs_multi"], g_dev:[], g_game:["qs_3a","qs_game_mid"] } },
  { name:"开发者 · 4~6K",
    picks:{ q2:"q2b", q3:"q3a", q4:"q4a", q5:"q5a", q6:"q6c", q7:"q7b", q8:"q8c", q9:"q9a" },
    side:{ g_work:["qs_multi"], g_dev:["qs_dev","qs_vm"], g_game:[] } },
  { name:"办公轻度 · 2.5~4K",
    picks:{ q2:"q2g", q3:"q3e", q4:"q4a", q5:"q5a", q6:"q6a", q7:"q7a", q8:"q8b", q9:"q9b" },
    side:{ g_work:["qs_office","qs_study","qs_media"], g_dev:[], g_game:[] } },
  { name:"视频剪辑 · 9~12K",
    picks:{ q2:"q2d", q3:"q3d", q4:"q4b", q5:"q5c", q6:"q6d", q7:"q7c", q8:"q8e", q9:"q9c" },
    side:{ g_work:[], g_dev:["qs_pr4k","qs_ps"], g_game:["qs_3a"] } },
  { name:"开发+游戏+设计 · 6~9K",
    picks:{ q2:"q2b", q3:"q3b", q4:"q4c", q5:"q5b", q6:"q6c", q7:"q7c", q8:"q8d", q9:"q9a" },
    side:{ g_work:["qs_multi"], g_dev:["qs_dev","qs_ps","qs_vm"], g_game:["qs_3a"] } },
];
