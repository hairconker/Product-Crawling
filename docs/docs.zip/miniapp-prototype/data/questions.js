/* 问卷数据 + 评分规则
   对齐《docs/小白装机问卷设计稿.md》§三 / §十一 / §十二。
   CommonJS 模块，框架无关——小程序 require 即可，Node 下也可用于单测。 */

const Q1_GROUPS = [
  { id:"g_work", title:"办公 / 学习", hint:"日常使用方向", opts:[
    { id:"qs_office", text:"日常办公",              s:{office:3, cpu:1} },
    { id:"qs_study",  text:"上网课 / 学习",          s:{office:2, balance:1} },
    { id:"qs_multi",  text:"多开网页 / 文档 / 聊天",  s:{cpu:2, office:1} },
    { id:"qs_stream", text:"开会 / 直播 / 录屏",      s:{cpu:1, balance:1} },
    { id:"qs_media",  text:"家用影音 / 追剧 / NAS",   s:{office:1} },
  ]},
  { id:"g_dev", title:"开发 / 创作", hint:"生产力方向", opts:[
    { id:"qs_dev",     text:"写代码 / 开发",              s:{cpu:3} },
    { id:"qs_vm",      text:"虚拟机 / Docker / 数据库",    s:{cpu:3} },
    { id:"qs_ps",      text:"PS / AI / Figma 平面设计",    s:{balance:2, gpu:1} },
    { id:"qs_pr",      text:"剪映 / PR / 达芬奇 1080P",    s:{gpu:2, cpu:1} },
    { id:"qs_pr4k",    text:"剪 4K / 高码率视频",          s:{gpu:3, cpu:2} },
    { id:"qs_cad",     text:"CAD / SketchUp / SolidWorks", s:{gpu:2, cpu:1} },
    { id:"qs_blender", text:"Blender / C4D / 3ds Max",    s:{gpu:3} },
  ]},
  { id:"g_game", title:"游戏 / 多开", hint:"娱乐方向，不玩可跳过", opts:[
    { id:"qs_3a",       text:"3A / 黑神话 / 赛博朋克",   s:{gpu:3} },
    { id:"qs_game_mid", text:"原神 / 永劫 / 吃鸡",       s:{gpu:2} },
    { id:"qs_game_lan", text:"LOL / CF / DOTA 网游",    s:{gpu:1, balance:1} },
    { id:"qs_emu",      text:"模拟器多开 / 云手机",        s:{cpu:2, gpu:1} },
  ]},
];

/* Q1 位次权重：类内小池，曲线陡 */
const SIDE_WEIGHTS = [1.0, 0.6, 0.3, 0.15];

const QUESTIONS = [
  { id:"q2", title:"下面哪种情况最接近你的实际使用？", opts:[
    { id:"q2a", text:"同时开很多网页/文档/聊天软件",           s:{cpu:2, office:1} },
    { id:"q2b", text:"会跑开发环境/数据库/虚拟机/Docker",       s:{cpu:3} },
    { id:"q2c", text:"会修图/排版/做海报",                   s:{balance:2, gpu:1} },
    { id:"q2d", text:"会剪 1080P / 4K 视频",                s:{gpu:2, cpu:1} },
    { id:"q2e", text:"会玩大型 3A 游戏",                    s:{gpu:3} },
    { id:"q2f", text:"会跑 3D / CAD / 建模渲染",            s:{gpu:3, cpu:1} },
    { id:"q2g", text:"只是轻度使用，不卡就行",              s:{office:3} },
  ]},
  { id:"q3", title:"你更在意哪一项？", opts:[
    { id:"q3a", text:"反应快、开软件快",     s:{cpu:2} },
    { id:"q3b", text:"多开不卡、运行稳定",   s:{cpu:2, balance:1} },
    { id:"q3c", text:"游戏帧数高",           s:{gpu:3} },
    { id:"q3d", text:"设计 / 渲染效率高",    s:{gpu:2, cpu:1} },
    { id:"q3e", text:"安静省电",             s:{office:2} },
    { id:"q3f", text:"性价比最高",           s:{balance:2} },
  ]},
  { id:"q4", title:"你会不会玩游戏？如果会，偏向哪类？", opts:[
    { id:"q4a", text:"基本不玩",                  s:{office:1} },
    { id:"q4b", text:"LOL / CF / DOTA2 这类网游", s:{gpu:1, balance:1} },
    { id:"q4c", text:"原神 / 永劫无间 / 吃鸡",    s:{gpu:2} },
    { id:"q4d", text:"黑神话 / 赛博朋克 / 3A 大作", s:{gpu:3} },
    { id:"q4e", text:"主机模拟器 / 多开游戏",     s:{cpu:2, gpu:1} },
  ]},
  { id:"q5", title:"你做设计或内容创作吗？", opts:[
    { id:"q5a", text:"不做",                            s:{} },
    { id:"q5b", text:"Photoshop / Illustrator / Figma", s:{balance:2, gpu:1} },
    { id:"q5c", text:"Premiere / 剪映 / 达芬奇",         s:{gpu:2, cpu:1} },
    { id:"q5d", text:"CAD / SketchUp / SolidWorks",    s:{gpu:2, cpu:1} },
    { id:"q5e", text:"Blender / C4D / 3ds Max",        s:{gpu:3} },
  ]},
  { id:"q6", title:"你对电脑寿命和升级的期待？", opts:[
    { id:"q6a", text:"能用就行，2~3 年够了",  s:{upgrade:0} },
    { id:"q6b", text:"希望 3~5 年都够用",     s:{upgrade:1} },
    { id:"q6c", text:"希望留升级空间",        s:{upgrade:2} },
    { id:"q6d", text:"一步到位，尽量别后悔",  s:{upgrade:3} },
  ]},
  { id:"q7", title:"你更偏向哪种预算心态？", opts:[
    { id:"q7a", text:"越便宜越好，够用就行",     s:{budget:0} },
    { id:"q7b", text:"性价比优先",               s:{budget:1} },
    { id:"q7c", text:"贵一点但要明显更舒服",     s:{budget:2} },
    { id:"q7d", text:"预算不是第一位，体验优先", s:{budget:3} },
  ]},
  { id:"q8", title:"你的整机预算更接近哪一档？", opts:[
    { id:"q8a", text:"2500 以内",        s:{budgetFloor:0} },
    { id:"q8b", text:"2500~4000",        s:{budgetFloor:1} },
    { id:"q8c", text:"4000~6000",        s:{budgetFloor:2} },
    { id:"q8d", text:"6000~9000",        s:{budgetFloor:3} },
    { id:"q8e", text:"9000~12000",       s:{budgetFloor:4} },
    { id:"q8f", text:"12000 以上",       s:{budgetFloor:5} },
    { id:"q8g", text:"还没想好，先看推荐", s:{} },
  ]},
  { id:"q9", title:"是否需要包含这些外设？", opts:[
    { id:"q9a", text:"只要主机",              s:{peripheral:0} },
    { id:"q9b", text:"主机 + 显示器",          s:{peripheral:1000} },
    { id:"q9c", text:"主机 + 显示器 + 键鼠",   s:{peripheral:1200} },
    { id:"q9d", text:"全套都要",              s:{peripheral:1500} },
  ]},
];

module.exports = { Q1_GROUPS, SIDE_WEIGHTS, QUESTIONS };
