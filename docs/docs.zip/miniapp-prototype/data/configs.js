/* 预算档位 + 三档配置模板
   对齐《docs/小白装机问卷设计稿.md》§十三 / §十四。
   硬件行情为 2026-04 估算，接入爬虫实价后替换即可（不改逻辑）。 */

const BUDGET_BUCKETS = [
  { level:0, label:"2500 以下",  lo:0,     hi:2499,  plan:2200  },
  { level:1, label:"2500~4000",  lo:2500,  hi:3999,  plan:3500  },
  { level:2, label:"4000~6000",  lo:4000,  hi:5999,  plan:5000  },
  { level:3, label:"6000~9000",  lo:6000,  hi:8999,  plan:7500  },
  { level:4, label:"9000~12000", lo:9000,  hi:11999, plan:10500 },
  { level:5, label:"12000 以上", lo:12000, hi:99999, plan:14000 },
];

const CONFIG_TEMPLATES = {
  "低功耗办公型": [
    { cpu:"Intel i3-12100", gpu:"核显 UHD 730", mem:"8GB DDR4",       ssd:"256GB NVMe",    psu:"额定 300W",      mb:"H610M",     range:[2000,2600] },
    { cpu:"Intel i3-13100", gpu:"核显 UHD 730", mem:"16GB DDR4",      ssd:"512GB NVMe",    psu:"额定 400W 铜牌", mb:"H610M",     range:[2800,3800] },
    { cpu:"Intel i5-12400", gpu:"核显 UHD 730", mem:"16GB DDR4",      ssd:"512GB NVMe",    psu:"额定 450W 铜牌", mb:"B760M",     range:[4000,5200] },
    { cpu:"Intel i5-13500", gpu:"核显 UHD 770", mem:"32GB DDR4",      ssd:"1TB NVMe",      psu:"额定 500W 金牌", mb:"B760M",     range:[5200,6800] },
    { cpu:"AMD R7-8700G",   gpu:"核显 780M",    mem:"32GB DDR5 6000", ssd:"1TB NVMe Gen4", psu:"额定 550W 金牌", mb:"B650M",     range:[7500,9200] },
    { cpu:"AMD R7-8700G",   gpu:"核显 780M",    mem:"64GB DDR5 6000", ssd:"2TB NVMe Gen4", psu:"额定 650W 金牌", mb:"B650M-ITX", range:[9500,11500] },
  ],
  "CPU优先": [
    { cpu:"Intel i3-13100F",  gpu:"GTX 1630 亮机",   mem:"16GB DDR4",      ssd:"512GB NVMe",    psu:"额定 450W 铜牌", mb:"H610M",       range:[2600,3400] },
    { cpu:"Intel i5-12400F",  gpu:"RX 6400 / 亮机",   mem:"16GB DDR4",      ssd:"512GB NVMe",    psu:"额定 500W 铜牌", mb:"B760M",       range:[3400,4200] },
    { cpu:"Intel i5-13490F",  gpu:"RTX 3050 6G",     mem:"32GB DDR4",      ssd:"1TB NVMe",      psu:"额定 550W 金牌", mb:"B760M",       range:[4800,6200] },
    { cpu:"Intel i7-14700KF", gpu:"RTX 4060 8G",     mem:"32GB DDR5 6000", ssd:"1TB NVMe Gen4", psu:"额定 650W 金牌", mb:"B760M WiFi",  range:[6800,8800] },
    { cpu:"Intel i7-14700KF", gpu:"RTX 4060 Ti 16G", mem:"64GB DDR5 6000", ssd:"2TB NVMe Gen4", psu:"额定 750W 金牌", mb:"Z790",        range:[9500,11800] },
    { cpu:"AMD R9-7950X",     gpu:"RTX 4070 Super",  mem:"64GB DDR5 6000", ssd:"2TB NVMe Gen4", psu:"额定 850W 金牌", mb:"X670E",       range:[13000,17000] },
  ],
  "GPU优先": [
    { cpu:"Intel i3-12100F",  gpu:"RX 6600 8G",         mem:"16GB DDR4", ssd:"500GB NVMe",    psu:"额定 500W 铜牌",  mb:"H610M",      range:[3000,3800] },
    { cpu:"Intel i5-12400F",  gpu:"RTX 3050 8G",        mem:"16GB DDR4", ssd:"500GB NVMe",    psu:"额定 550W 铜牌",  mb:"B760M",      range:[3800,4800] },
    { cpu:"Intel i5-12400F",  gpu:"RTX 4060 8G",        mem:"16GB DDR5", ssd:"1TB NVMe",      psu:"额定 650W 金牌",  mb:"B760M",      range:[5200,6500] },
    { cpu:"Intel i5-14600KF", gpu:"RTX 4060 Ti 16G",    mem:"32GB DDR5", ssd:"1TB NVMe Gen4", psu:"额定 750W 金牌",  mb:"B760M WiFi", range:[7000,9000] },
    { cpu:"Intel i7-14700KF", gpu:"RTX 4070 Super 12G", mem:"32GB DDR5", ssd:"2TB NVMe Gen4", psu:"额定 850W 金牌",  mb:"Z790 WiFi",  range:[9800,12000] },
    { cpu:"Intel i7-14700KF", gpu:"RTX 4080 Super 16G", mem:"64GB DDR5", ssd:"2TB NVMe Gen4", psu:"额定 1000W 金牌", mb:"Z790 WiFi",  range:[14000,19000] },
  ],
  "均衡型": [
    { cpu:"Intel i3-13100F",  gpu:"RX 6600 8G",        mem:"16GB DDR4", ssd:"500GB NVMe",    psu:"额定 500W 铜牌", mb:"H610M",       range:[2800,3600] },
    { cpu:"Intel i5-12400F",  gpu:"RTX 3050 8G",       mem:"16GB DDR4", ssd:"500GB NVMe",    psu:"额定 550W 铜牌", mb:"B760M",       range:[3600,4600] },
    { cpu:"Intel i5-13490F",  gpu:"RTX 4060 8G",       mem:"32GB DDR4", ssd:"1TB NVMe",      psu:"额定 650W 金牌", mb:"B760M",       range:[5000,6500] },
    { cpu:"Intel i5-14600KF", gpu:"RTX 4060 Ti 8G",    mem:"32GB DDR5", ssd:"1TB NVMe Gen4", psu:"额定 750W 金牌", mb:"B760M WiFi",  range:[6800,8500] },
    { cpu:"AMD R7-7800X3D",   gpu:"RTX 4070 12G",      mem:"32GB DDR5", ssd:"1TB NVMe Gen4", psu:"额定 750W 金牌", mb:"B650 WiFi",   range:[9000,11500] },
    { cpu:"AMD R7-7800X3D",   gpu:"RTX 4070 Ti Super", mem:"64GB DDR5", ssd:"2TB NVMe Gen4", psu:"额定 850W 金牌", mb:"X670E WiFi",  range:[13000,16000] },
  ],
};

module.exports = { BUDGET_BUCKETS, CONFIG_TEMPLATES };
